# Folio 2019

## Setup
Download [Node.js](https://nodejs.org/en/download/).
Run this followed commands:

``` bash
# Just be sure that you've got parcel js on you system
npm install -g parcel-bundler

# Install dependencies (only for first time)
npm i

# Serve at localhost:1234
npm run dev

# Build for production in the dist/ directory
npm run build
```

```
🥚 2021eggpvlzscw
```
